# Landing Page Project
## Table of Contents
 Description

 Instructions

 Styles

 Acknowledgement

## Description
 This project is build on using HTML,CSS and Vanilla JavaScript. It implements DOM manipulation to toggle active classes on HTML elements.
## Instructions
To start the application, use simple python HTTP server:
 
     python3 -m http.server 8000
## Styles 
This project follows the basic WebStorm coding styles.

## Acknowledgement
 MDN
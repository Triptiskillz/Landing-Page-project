# Landing Page Project
## Table of Content 
 Description

 Instructions

 Styles

 Acknowledgement
## Description
 This project is build on using HTML,CSS and Vanilla JavaScript. It implements DOM manipulation to toggle active classes on HTML elements.

## Styles 
This project follows the basic WebStorm coding styles.

## Acknowledgement
 MDN